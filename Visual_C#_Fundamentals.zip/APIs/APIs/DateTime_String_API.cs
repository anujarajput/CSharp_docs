﻿using System;

namespace APIs
{
    class DateTime_String_API
    {
        static void Main()
        {
            Console.WriteLine($"Date and Time:{DateTime.Now}");
            Console.WriteLine($"Date:{DateTime.Now.Date}");//with time
            Console.WriteLine($"Date:{DateTime.Now.Date.ToString("dd-mm-yyyy")}");//with given format(time is ommited)
            Console.WriteLine($"Todays Date:{DateTime.Now.Day}/{DateTime.Now.Month}/{DateTime.Now.Year}");
            Console.WriteLine($"Enter days which you want to add:");
            //double days = Convert.ToDouble(Console.ReadLine());
            //Console.WriteLine($"Date after adding {days} Days:{DateTime.Now.Date.AddDays(days).ToString("dd-mm-yyyy")}");

            Console.WriteLine($"---------------------------------");

            //Console.WriteLine("Enter the Date");

            //DateTime mydate = Convert.ToDateTime(Console.ReadLine());

            //int result = mydate.CompareTo(DateTime.Now.Date);

            //if(result == 0)
            //{
            //    Console.WriteLine($"Entered Date and required Date{mydate} are same");
            //}
            //else if (result == 1)
            //{
            //    Console.WriteLine($"Entered Date {mydate.ToString("dd-mm-yyyy")} newer than required Date {DateTime.Now.Date.ToString("dd-mm-yyyy")}");
            //}
            //else
            //{
            //    Console.WriteLine($"Entered Date {mydate.ToString("dd-mm-yyyy")} older than required Date {DateTime.Now.Date.ToString("dd-mm-yyyy")}");
            //}
            Console.WriteLine($"---------------------------------------");
            Console.WriteLine($"Duration calculation:");
            
            Console.WriteLine($"Enter Start Date:");
            DateTime date1 = Convert.ToDateTime(Console.ReadLine());

            Console.WriteLine($"Enter End Date:");
            DateTime date2 = Convert.ToDateTime(Console.ReadLine());

            double days = date2.Date.ToOADate() - date1.Date.ToOADate();
            Console.WriteLine($"Duration in days:{days}");

            Console.ReadLine();
        }
    }
}
