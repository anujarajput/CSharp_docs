﻿using System;

namespace APIs
{
    class String_API
    {
        static void Main()
        {
            string str1 = "This is a String Class";
            string str2 = String.Copy(str1);
            Console.WriteLine($"String1 : {str1}");
            Console.WriteLine($"String2 : {str2}");

            Console.WriteLine($"StartsWith:");

            string search = "this";
            if(str1.StartsWith(search, StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine($"String starts with {search}");
            }
            else
            {
                Console.WriteLine($"String do not starts with {search}");
            }
            Console.WriteLine($"---------------------------");
            //Console.WriteLine($"Substring:");
            //string sub = str1.Substring(8, 15);
            //Console.WriteLine($"Sub string : {sub}");
            string spaces = string.Empty;
            foreach(string s in str1.Split(' '))
            {
                spaces += s;
            }
            Console.WriteLine($"After removing white spaces {spaces}");

            Console.ReadLine();
        }
    }
}
