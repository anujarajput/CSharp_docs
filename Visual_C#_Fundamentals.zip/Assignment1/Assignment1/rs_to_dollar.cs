﻿using System;

namespace Assignment1
{
    class rs_to_dollar
    {
        static void Main()
        {
            Console.WriteLine("Enter RS value :");
            int rs = Convert.ToInt32(Console.ReadLine());

            double dolr  = Convert.ToDouble(rs * (1/71.05) );

            Console.WriteLine("RS {0} = $ {1}", rs, dolr);

            Console.ReadLine();

        }
    }
}
