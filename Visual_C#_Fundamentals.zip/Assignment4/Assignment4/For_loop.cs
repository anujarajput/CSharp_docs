﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    class For_loop
    {
        static void Main()
        {
          
            for(int i = 50; i >= 1; i--)
            {
                Console.WriteLine(i);
            }

            Console.ReadLine();
        }
    }
}
