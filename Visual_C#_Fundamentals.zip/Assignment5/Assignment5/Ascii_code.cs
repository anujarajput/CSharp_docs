﻿using System;

namespace Assignment5
{
    class Ascii_code
    {
        static void Main()
        {
            int[,] arr = new int[3, 3];
            char ch = 'A';

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    arr[i, j] = ch;
                    ch++;
                    
                }
            }

            Console.WriteLine("-------------------------------------");
            Console.WriteLine("Ascii code for A to I in array:");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t", arr[i, j]);
                }
                Console.WriteLine();
            }

            Console.ReadLine();
        }
    }
}
