﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    class sum_of_diagonal_ele
    {
        static void Main()
        {
            int[,] arr = new int[3, 3];

            Console.WriteLine("Please enter Array elemets for 2dimensional array :");
            
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    
                        arr[i,j] = Convert.ToInt32(Console.ReadLine());
                    
                }
            }
            Console.WriteLine("-------------------------------------");
            Console.WriteLine("Entered array:");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t",arr[i,j]);
                }
                Console.WriteLine();
            }

            Console.WriteLine("-------------------------------------");
            Console.WriteLine();

            int sum = 0;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if(i == j)
                    {
                        sum = sum + arr[i, j];
                    }
                } 
            }

            Console.WriteLine("Sum of diagonal Elements:{0}", sum);



            Console.ReadLine();
            

        }
    }
}
