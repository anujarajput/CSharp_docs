﻿using System;

namespace Assignment6
{
    class Simple_interest_using_outcs
    {
        static void Main()
        {
            Console.WriteLine("Please enter Principal(in RS):");
            double p = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Please enter Number of time period(in years):");
            double n = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Please enter Rate of interest(in %):");
            double r = Convert.ToInt32(Console.ReadLine());

            double payable_amount;

            Calc_interest(out payable_amount, p, n, r);

            Console.WriteLine($"Total payable amount for RS {p} for {n} years on {r}% rate of interest : {payable_amount}");

            Console.ReadLine();
        }

        public static double Calc_interest(out double payable_amount, double p, double n, double r)
        {
            double total_int = 0;
            total_int = (p * n * r) / 100;

            payable_amount = total_int + p;

            return payable_amount;
        }
        
        
    }
}
