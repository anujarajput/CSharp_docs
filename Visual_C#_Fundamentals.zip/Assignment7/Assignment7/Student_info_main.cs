﻿using System;

namespace Assignment7
{
    class Student_info_main
    {
        static void Main()
        {
            Console.WriteLine("Enter Roll number:");
            int roll_no = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Student name:");
            string s_name = Console.ReadLine();
            Console.WriteLine("Enter Gender:");
            char s_gender = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("Enter Contact number:");
            double cont_no = Convert.ToInt32(Console.ReadLine());

            Student_info std_info = new Student_info(roll_no, s_name, s_gender, cont_no);

            Console.WriteLine(std_info.Display_info());

            Console.ReadLine();
        }
    }
}
