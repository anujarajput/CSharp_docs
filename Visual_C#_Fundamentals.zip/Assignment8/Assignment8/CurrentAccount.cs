﻿using System;

namespace Assignment8
{
    class CurrentAccount:IBankAccount       
    {

        double acc_avilable_balance = 23256;

        public void Deposit(double amount)
        {
            Console.WriteLine($"Your current Transaction is succesful. Rs. {amount} is succesfully Deposited.");
            acc_avilable_balance = acc_avilable_balance + amount;
            Show_Current_balance();
        }

        public void Withdraw(double amount)
        {
            if (amount < acc_avilable_balance)
            {
                Console.WriteLine($"Your current Transaction is succesful. Rs. {amount} is succesfully Withdrawed.");
                acc_avilable_balance = acc_avilable_balance - amount;
                Show_Current_balance();
            }
            else
            {
                Console.WriteLine("Insufficient Balance.");
                Show_Current_balance();
            }

        }
        public void Show_Current_balance()
        {
            Console.WriteLine($"Yor Current account Balance: RS {acc_avilable_balance}");
        }
    }
}
