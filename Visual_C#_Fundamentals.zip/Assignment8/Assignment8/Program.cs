﻿using System;

namespace Assignment8
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
