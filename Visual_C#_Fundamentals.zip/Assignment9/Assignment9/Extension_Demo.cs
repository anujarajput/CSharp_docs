﻿using System;

namespace Assignment9
{
    public static class Extension_Demo
    {
        public static bool isPositive(this int num)
        {
            return num > 0;
        }
    }

    class Test_Extension
    {
        static void Main()
        {
            Console.WriteLine("Please enter 1st number");
            int num1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Please enter 2nd number");
            int num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(num1.isPositive() ? $"Addition:{num1 + num2}" : "Please Enter positive Value");

            Console.ReadLine();


        }
    }
}
