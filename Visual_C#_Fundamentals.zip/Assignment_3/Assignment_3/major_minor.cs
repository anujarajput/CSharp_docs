﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3
{
    class major_minor
    {
        static void Main()
        {
            Console.WriteLine("Please enter your age:");
            int age = Convert.ToInt32(Console.ReadLine());
            if(age >= 18)
            {
                Console.WriteLine("Major Person.");
            }
            else
            {
                Console.WriteLine("Minor Person.");
            }

            Console.ReadLine();
        }
    }
}
