﻿using System;

namespace Assignment1
{
    class area
    {
        static void Main()
        {
            const double PI = 3.14;//constant

            Console.WriteLine("Enter radius:");
            int rad = Convert.ToInt32(Console.ReadLine());
        
            double area = PI * rad * rad;

            Console.WriteLine("Area of circle of radious {0} = {1}", rad, area);

            Console.ReadLine();

        }
    }
}
