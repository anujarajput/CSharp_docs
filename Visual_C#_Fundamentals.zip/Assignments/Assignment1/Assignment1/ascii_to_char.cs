﻿using System;

namespace Assignment1
{
    class ascii_to_char
    {
        static void Main()
        {
            Console.WriteLine("Enter ASCII code :");
            int ascii = Convert.ToInt32(Console.ReadLine());
            
        char chr = (char)ascii; //type casting int to char

        Console.WriteLine("Character for ASCII code {0} = {1}", ascii, chr);

        Console.ReadLine();
        }
    }
}
