﻿using System;

namespace Assignment4
{
    class Foreach_even
    {
        //Program to display even numbers between 1 to 50 using foreach

        static void Main()
        {
            int[] arr = new int[51];
            for (int i = 1; i <= 50; i++)
            {
                arr[i] = i;
            }

            foreach (int temp in arr)
            {
                if (temp % 2 == 0)
                {
                    Console.WriteLine(temp);
                }
            }

            Console.ReadLine();
        }
    }
}
