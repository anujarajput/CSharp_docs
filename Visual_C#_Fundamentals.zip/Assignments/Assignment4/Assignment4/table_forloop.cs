﻿using System;

namespace Assignment4
{
    class table_forloop
    {
        //Program to print table of given number

        static void Main()
        {
            Console.WriteLine("Please enter the number:");
            int num = Convert.ToInt32(Console.ReadLine());
            int tbl = 1;
            Console.WriteLine("Table for {0}:",num);
            for (int i=1; i<=10; i++)
            {
                tbl = num * i;
                Console.WriteLine(tbl);
            }

            Console.ReadLine();
        }
    }
}
