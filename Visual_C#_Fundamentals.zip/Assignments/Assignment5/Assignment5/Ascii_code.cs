﻿using System;

namespace Assignment5
{
    class Ascii_code
    {
        //Program to print ASCII codes of char right from a to i.

        static void Main()
        {
            int[,] arr = new int[3, 3];
            char ch = 'A';//taking starting char A

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    arr[i, j] = ch;//converting char to int
                    ch++;
                    
                }
            }

            //printing array

            Console.WriteLine("-------------------------------------");
            Console.WriteLine("Ascii code for A to I in array:");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t", arr[i, j]);
                }
                Console.WriteLine();
            }

            Console.ReadLine();
        }
    }
}
