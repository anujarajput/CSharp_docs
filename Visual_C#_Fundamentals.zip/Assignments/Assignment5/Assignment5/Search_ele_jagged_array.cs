﻿using System;

namespace Assignment5
{
    class Search_ele_jagged_array
    {
        //Program to search element from Jagged array

        static void Main()
        {
            int[][] arr = new int[3][];
            arr[0] = new int[3] { 10, 20, 30 };
            arr[1] = new int[3] { 60, 25, 42 };
            
            Console.WriteLine("Enter search elemet"); //taking element to search from user
            int arr_ele = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("--------------------------");
            Console.WriteLine("Array:");
            for (int i=0; i < 2; i++)
            {
                foreach(var temp in arr[i])
                {
                        Console.Write("{0}\t", temp);
                }
                Console.WriteLine();
            }

            Console.WriteLine("--------------------------");

            for (int i=0; i < 2; i++)
            {
                foreach(var temp in arr[i])
                {
                    if (temp == arr_ele)
                    {
                        Console.WriteLine("Entered elemt found:{0}", temp);
                    }
                }
            }

            Console.ReadLine();
        }
    }
}
