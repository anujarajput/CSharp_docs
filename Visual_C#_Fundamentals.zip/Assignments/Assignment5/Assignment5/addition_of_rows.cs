﻿using System;

namespace Assignment5
{
    class addition_of_rows
    {
        //Program to print sum of each row for multi dimesional array

        static void Main()
        {
            int[,] arr = new int[3, 3];

            //taking array from user

            Console.WriteLine("Please enter Array elemets for array(9 elements) :");

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {

                    arr[i, j] = Convert.ToInt32(Console.ReadLine());

                }
            }
            Console.WriteLine("-------------------------------------");

            //priting array

            Console.WriteLine("Entered array:");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t", arr[i, j]);
                }
                Console.WriteLine();
            }

            Console.WriteLine("-------------------------------------");
            Console.WriteLine();

            //printing sum of rows

            int sum = 0;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    sum = sum + arr[i, j];
                }
                Console.WriteLine("Sum of row {0} = {1}", i+1, sum);
            }
            
            Console.ReadLine();
        }
    }
}
