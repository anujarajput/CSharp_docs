﻿using System;

namespace Assignment5
{
    class sum_of_diagonal_ele
    {
        //Program to display sum of diagonal elements of array

        static void Main()
        {
            int[,] arr = new int[3, 3];

            Console.WriteLine("Please enter Array elemets for 2dimensional array :"); // taking array input from user
            
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    
                        arr[i,j] = Convert.ToInt32(Console.ReadLine());
                    
                }
            }
            Console.WriteLine("-------------------------------------");
            Console.WriteLine("Entered array:");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t",arr[i,j]);
                }
                Console.WriteLine();
            }

            Console.WriteLine("-------------------------------------");
            Console.WriteLine();

            int sum = 0;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if(i == j)
                    {
                        sum = sum + arr[i, j]; //addition of diagonal elements
                    }
                } 
            }

            Console.WriteLine("Sum of diagonal Elements:{0}", sum); //printing result



            Console.ReadLine();
            

        }
    }
}
