﻿using System;

namespace Assignment7
{
    //Program to maintain City names and STD codes using enum

    class City_enum_main
    {
        static void Main()
        {
            //print all enum states
            Console.WriteLine("All available cities:");
            foreach (string state in Enum.GetNames(typeof(City_std_code)))
            {
                Console.WriteLine(state);
            }
            Console.WriteLine("-----------------------------------");
            //print all std code
            Console.WriteLine("Std code for all cities:");
            foreach (int val in Enum.GetValues(typeof(City_std_code)))
            {
                Console.WriteLine(val);
            }

            Console.ReadLine();
        }
    }
}
