﻿using System;

namespace Assignment8
{
    //Abstract class Demo

    abstract class Computer
    {
        public abstract string BootUp();

        public abstract string ShutDown();
    }

    class SuperComputer : Computer
    {
        /// <summary>
        /// Implimenting methods from abstract class
        /// </summary>
        public override string BootUp()
        {
            return "SuperComputer Booting Up";
        }

        public override string ShutDown()
        {
            return "SuperComputer Shutting Down";
        }
    }

    class MainfraimComputer : Computer
    {
        /// <summary>
        /// Implementing methods from inherited abstract class
        /// </summary>
        public override string BootUp()
        {
            return "MainfraimComputer Booting Up";
        }

        public override string ShutDown()
        {
            return "MainfraimComputer Shutting Down";
        }
    }

    class MicroComputer : Computer
    {
        /// <summary>
        /// Implimenting methods from abstract class 
        /// </summary>
        public override string BootUp()
        {
            return "MicroComputer Booting Up";
        }

        public override string ShutDown()
        {
            return "MicroComputer Shutting Down";
        }
    }

    class ComputerMain
    {
        static void Main()
        {

            SuperComputer s_comp = new SuperComputer();
            Console.WriteLine(s_comp.BootUp());
            Console.WriteLine(s_comp.ShutDown());

            MainfraimComputer main_comp = new MainfraimComputer();
            Console.WriteLine(main_comp.BootUp());
            Console.WriteLine(main_comp.ShutDown());

            MicroComputer micro_comp = new MicroComputer();
            Console.WriteLine(micro_comp.BootUp());
            Console.WriteLine(micro_comp.ShutDown());

            Console.ReadLine();

        }
    }
}
