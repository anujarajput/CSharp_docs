﻿using System;

namespace Assignment8
{
    //Sealed class demo

    sealed class Pen
    {

        public string StartWriting()
        {
            return "Pen started to Write...";
        }

        public string StopWriting()
        {
            return "Pen stopped to Writing..";
        }
    }

    class Pen_main
    {
        static void Main()
        {
            Pen pn = new Pen();
            Console.WriteLine(pn.StartWriting());
            Console.WriteLine(pn.StopWriting());

            Console.ReadLine();
        }

    }
}
