﻿using System;

namespace Chapter10
{
    class AnonymusFunction_Demo
    {
        public delegate void Print(int value);

        static void Main()
        {
            Print print = delegate (int num)
            {
                Console.WriteLine($"Entered number = {num}");
            };

            Console.WriteLine("Please enter the number");
            int number = Convert.ToInt32(Console.ReadLine());

            print(number*100);

            Console.ReadLine();

        }
    }
}
