﻿using System;


namespace Chapter10
{
    class Deligate_Demo
    {
        public delegate void Print(int value);

        static void Main()
        {
            Print print = new Print(PrintNumber);

            Console.WriteLine("Please enter the number");
            int num = Convert.ToInt32(Console.ReadLine());

            print(num);
            
            print = PrintRS;

            print(100*num);

            //Attach function to deligate
            //print += PrintRS;
            //detach function from deligate
            //print -= PrintRS

            Console.ReadLine();
        }
        
        public static void PrintNumber(int num)
        {
            Console.WriteLine($"Entered Number: {num}");
        }
        
        public static void PrintRS(int rs)
        {
            Console.WriteLine($"RS:{rs}");
        }

    }
}
