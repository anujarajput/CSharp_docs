﻿using System;

namespace Chapter10
{
    class Equals_Demo
    {
        static void Main()
        {
            int num1 = 20;
            double num2 = num1;

            Console.WriteLine(num1.Equals(num2)); //compares values
            Console.WriteLine(num1 == num2); //compares reference

            Console.WriteLine(num1.GetHashCode());
            Console.WriteLine(num2.GetHashCode());


            Console.ReadLine();

        }
    }
}
