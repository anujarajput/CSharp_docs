﻿using System;

namespace Chapter10
{
    public static class Extension2
    {
        public static bool isPositive(this int num)
        {
            return num > 0;
        }

    }

    class Extenstion2_main
    {
        
        static void Main()
        {
            Console.WriteLine("Please enter 1st number");
            int num1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Please enter 2nd number");
            int num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(num1.isPositive() ? $"Addition:{num1+num2}" : "Please Enter positive Value");

            Console.ReadLine();

            
        }
    }
}
