﻿using System;

namespace Chapter10
{
    public static class Extension_Demo
    {
        public static bool IsGreaterThan(this int i, int value)
        {
            return i < value;
        }
    }

    class Test_Extension
    {
        static void Main()
        {
            int i = 100;
            Console.WriteLine("Enter the Number");
            int num = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(i.IsGreaterThan(num) ? "Greater" : "Smaller");

            Console.ReadLine();
        }
    }
}
