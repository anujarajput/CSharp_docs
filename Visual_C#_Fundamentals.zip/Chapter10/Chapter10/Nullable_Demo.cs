﻿using System;
using System.Collections.Generic;

namespace Chapter10
{
    class Nullable_Demo
    {
        static void Main()
        {
            Nullable<int> num1 = null;
            Nullable<int> num2 = 100;
            Nullable<int> num3 = num1 + num2;
            int? num4 = null; //Nullable shorthand property

            if (num1.HasValue)
            {
                Console.WriteLine($"Value:{num1.GetValueOrDefault()}");
            }
            else
            {
                Console.WriteLine("Object is NULL");
            }
            
            Console.ReadLine();
        }
    }
}
