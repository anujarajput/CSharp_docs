﻿using System;
using System.Collections.Generic;

namespace Chapter10
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
