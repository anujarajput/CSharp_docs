﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Chapter10
{
    class Serialization_Demo
    {
        static void Main()
        {
            //DoSerialization();
            DoDeSerialization();
        }

        public static void DoSerialization()
        {
            //declaring obj to be serialize
            Employee emp = new Employee();
            emp.id = 300;
            emp.name = "GSHFSHFV";
            emp.gender = "male";

            FileInfo file = new FileInfo("employee.dat");
            Stream stream = file.Open(FileMode.Create);

            BinaryFormatter binary = new BinaryFormatter(); //can transfer this binary object over network by using TCPIP
            binary.Serialize(stream, emp);

            Console.WriteLine("emp object is serialized");

            Console.ReadLine();
        }

        public static void DoDeSerialization()
        {
            Employee emp = new Employee();
            FileInfo file = new FileInfo("employee.dat");
            Stream stream = file.Open(FileMode.Open);

            BinaryFormatter binary = new BinaryFormatter();
            emp = (Employee)binary.Deserialize(stream); //type castiong in to Employee type

            Console.WriteLine($"ID={emp.id} | Name:{emp.name} | Gender:{emp.gender}");

            Console.ReadLine();
        }
    }
}
