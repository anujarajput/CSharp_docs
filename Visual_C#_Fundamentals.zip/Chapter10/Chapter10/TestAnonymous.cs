﻿using System;
using System.Collections.Generic;

namespace Chapter10
{
    class TestAnonymous
    {
        static void Main()
        {
            List<Employee> emp_list = new List<Employee>()
            {
                new Employee{id=101, name="ABC", gender="male"},
                new Employee{id=102, name="PQR", gender="female"},
                new Employee{id=103, name="MNS", gender="female"},
                new Employee{id=104, name="XYZ", gender="male"}
            };

            Predicate<Employee> emp_predicate = new Predicate<Employee>(GetEmp);

            Employee emp = emp_list.Find(x => emp_predicate(x)); //extension method

            Console.WriteLine($"ID={emp.id} | Name={emp.name} | Gender={emp.gender}");


            Console.ReadLine();
        }

        public static bool GetEmp(Employee emp)
        {
            return emp.id == 103;
        }
    }
}
