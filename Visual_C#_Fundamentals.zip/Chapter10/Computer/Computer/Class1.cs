﻿using System;

namespace Computer
{
    public class Software
    {
        string AppType;
        string AppName;
        int AppVer;

        public Software(string AppType, string AppName, int AppVer)
        {
            this.AppType = AppType;
            this.AppName = AppName;
            this.AppVer = AppVer;
        }

        public string Dispalay()
        {
            return $"Application type={AppType} Name={AppName} Version={AppVer}";
        }
    }
}
