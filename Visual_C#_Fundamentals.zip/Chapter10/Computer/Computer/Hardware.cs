﻿using System;

namespace Computer
{
    public class Hardware
    {
        string DeviceType;
        string DeviceName;
        int DeviceId;

        public Hardware(string DeviceType, string DeviceName, int DeviceId)
        {
            this.DeviceType = DeviceType;
            this.DeviceName = DeviceName;
            this.DeviceId = DeviceId;
        }
        
        public string Display()
        {
            return $"Device type={DeviceType} Name={DeviceName} Version={DeviceId}";
        }

    }
}
