﻿using System;
using Computer;

namespace Computer_namespace
{
    class Program
    {
        static void Main(string[] args)
        {
            Software s = new Software("Application", "MS", 2019);
            Console.WriteLine(s.Dispalay());

            Console.ReadLine();
        }
    }
}
