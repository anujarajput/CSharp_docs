﻿using System;
using System.IO;

namespace Chapter11
{
    class Directory_Demo
    {
        static void Main()
        {
            DirectoryInfo directory = new DirectoryInfo("MyDirectory");
            DirectoryInfo directory2 = new DirectoryInfo("MyDirectory2");

            if (!directory.Exists && !directory2.Exists)
            {
                directory.Create();
                directory2.Create();
                Console.WriteLine("Directory created successfully");
                Console.WriteLine($"---------------------------------------------");
            }
            else
            {
                Console.WriteLine("Directory already exist");
            }

            if (directory.Exists)
            {
                Console.WriteLine($"Name:{directory.Name}");
                Console.WriteLine($"FullName:{directory.FullName}");
                Console.WriteLine($"Parent:{directory.Parent}");
                Console.WriteLine($"Attributes:{directory.Attributes}");
                Console.WriteLine($"Root:{directory.Root}");
                Console.WriteLine($"CreationTime:{directory.CreationTime}");
                Console.WriteLine($"LastAccessTime:{directory.LastAccessTime}");
                Console.WriteLine($"LastWriteTime:{directory.LastWriteTime}");
                Console.WriteLine($"---------------------------------------------");
            }
            else
            {
                Console.WriteLine("Directory not Fount");
            }

            if (directory2.Exists)
            {
                directory2.Delete();
                Console.WriteLine($"Directory deleted successfully");
                Console.WriteLine($"---------------------------------------------");
            }
            else
            {
                Console.WriteLine("Directory not Fount..");
            }

            if (directory.Exists)
            {
                foreach(DirectoryInfo d in directory.GetDirectories())
                {
                    Console.WriteLine($"{d.Name} directory is deleted");
                    d.Delete();
                }
                Console.WriteLine($"---------------------------------------------");
            }
            else
            {
                Console.WriteLine("Directory not Fount");
            }

            if (directory.Exists)
            {
                foreach(FileInfo f in directory.GetFiles())
                {
                    Console.WriteLine($"{f.Name} file is deleted");
                    f.Delete();
                }
                Console.WriteLine($"---------------------------------------------");
            }
            else
            {
                Console.WriteLine("Directory not Fount");
            }


            Console.ReadLine();
        }
    }
}
