﻿using System;
using System.IO;

namespace Chapter11
{
    class DriveInfo_Demo
    {
        static void Main()
        {
            DriveInfo drive = new DriveInfo("D:");

            if (drive.IsReady)
            {
                Console.WriteLine($"{drive} Drive is ready..");
                Console.WriteLine($"--------------------------------");
                Console.WriteLine($"Name:{drive.Name}");
                Console.WriteLine($"VolumeLabel:{drive.VolumeLabel}");
                Console.WriteLine($"TotalSize:{((drive.TotalSize/1024)/1024)/1024}GB");
                Console.WriteLine($"AvailableFreeSpace:{((drive.AvailableFreeSpace / 1024) / 1024) / 1024}GB");
                Console.WriteLine($"TotalFreeSpace:{((drive.TotalFreeSpace / 1024) / 1024) / 1024}GB");
                Console.WriteLine($"RootDirectory:{drive.RootDirectory}");
                Console.WriteLine($"DriveFormat:{drive.DriveFormat}");
                Console.WriteLine($"DriveType:{drive.DriveType}");
                Console.WriteLine($"-------------------------------------");

            }
            else
            {
                Console.WriteLine($"Drive not available...");
            }


            Console.WriteLine($"Available Drive on disk");
            Console.WriteLine($"-------------------------------------");
            foreach (DriveInfo drv in DriveInfo.GetDrives())
            {
                if (drv.IsReady)
                {
                    Console.WriteLine($"Name:{drv.Name}");
                    Console.WriteLine($"VolumeLabel:{drv.VolumeLabel}");
                    Console.WriteLine($"TotalSize:{((drv.TotalSize / 1024) / 1024) / 1024}GB");
                    Console.WriteLine($"AvailableFreeSpace:{((drv.AvailableFreeSpace / 1024) / 1024) / 1024}GB");
                    Console.WriteLine($"TotalFreeSpace:{((drv.TotalFreeSpace / 1024) / 1024) / 1024}GB");
                    Console.WriteLine($"RootDirectory:{drv.RootDirectory}");
                    Console.WriteLine($"DriveFormat:{drv.DriveFormat}");
                    Console.WriteLine($"DriveType:{drv.DriveType}");
                    Console.WriteLine($"-------------------------------------");
                }
            }


            Console.ReadLine();
        }
    }
}
