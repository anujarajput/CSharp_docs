﻿using System;
using System.IO;
namespace Chapter11
{
    class FileInfo_Demo
    {
        static void Main()
        {
            FileInfo file = new FileInfo("try.txt");
            if (file.Exists)
            {
                Console.WriteLine($"File available");
                Console.WriteLine($"Path:{file.FullName}");
                Console.WriteLine($"Name:{file.Name}");
                Console.WriteLine($"Directory:{file.Directory}");
                Console.WriteLine($"DirectoryName:{file.DirectoryName}");
                Console.WriteLine($"Length:{file.Length}");
                Console.WriteLine($"Extension:{file.Extension}");
                Console.WriteLine($"Attributes:{file.Attributes}");
                Console.WriteLine($"IsReadOnly:{file.IsReadOnly}");
                Console.WriteLine($"Creation time:{file.CreationTime}");
                Console.WriteLine($"Last Access time:{file.LastAccessTime}");
                Console.WriteLine($"Last Write Time:{file.LastWriteTime}");
                Console.WriteLine($"----------------------------------------");

            }
            else
            {
                Console.WriteLine("File not Fount");
            }

            if (file.Exists)
            {
                file.CopyTo(@"D:\Demo_58131\Visual_C#_Fundamentals\Chapter11\Chapter11\bin\Debug\FileInfo1.txt");
                Console.WriteLine($"File copied successfully");
                Console.WriteLine($"-------------------------------------");
            }
            else
            {
                Console.WriteLine("File not fount");
            }

            if (file.Exists)
            {
                //file.MoveTo(@"D:\Demo_58131\Visual_C#_Fundamentals\Chapter11\Chapter11\bin\Debug\FileInfo2.txt");
                Console.WriteLine($"File Moved successfully");
                Console.WriteLine($"-------------------------------------");
            }
            else
            {
                Console.WriteLine("File not fount");
            }

            if (file.Exists)
            {
                file.Delete();
                Console.WriteLine($"File Deleted successfully");
                Console.WriteLine($"-------------------------------------");
            }
            else
            {
                Console.WriteLine("File not fount");
            }


            Console.ReadLine();
        }
    }
}
