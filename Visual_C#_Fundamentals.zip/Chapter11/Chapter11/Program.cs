﻿using System;
using System.IO;

namespace Chapter11
{
    class Program
    {
        static void Main(string[] args)
        {
            //StreamWriter stream = new StreamWriter(@"C:\try.txt"); //Absolute path
            StreamWriter stream = new StreamWriter("try.txt");

            Console.WriteLine("Please write a Message");
            string str = Console.ReadLine();

            stream.WriteLine(str);
            stream.Close();

            Console.WriteLine("File has written successfully");

            Console.ReadLine();
        }
    }
}
