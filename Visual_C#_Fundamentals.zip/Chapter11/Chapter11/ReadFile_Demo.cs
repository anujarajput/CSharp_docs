﻿using System;
using System.IO;

namespace Chapter11
{
    class ReadFile_Demo
    {
        static void Main()
        {
            StreamReader stream = new StreamReader("try.txt");
            string str = stream.ReadToEnd();

            Console.WriteLine(str);

            Console.ReadLine();
        }
    }
}
