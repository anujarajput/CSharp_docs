﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter4
{
    class do_while_Demo
    {
        static void Main()
        {
            int i = 1;
            int sum = 0;
            do
            {
                sum = sum + i;
                Console.WriteLine(sum);
                i++;
            }
            while (i <= 15);
            Console.ReadLine();
        }
    }
}
