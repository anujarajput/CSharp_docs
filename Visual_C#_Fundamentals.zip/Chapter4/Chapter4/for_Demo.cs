﻿using System;

namespace Chapter4
{
    class for_Demo
    {
        static void Main()
        {
            int sum = 0;
            for(int i =1; i<=15; i++)
            {
                sum = sum + i;
                Console.WriteLine(sum);
            }

            Console.ReadLine();
        }
    }
}
