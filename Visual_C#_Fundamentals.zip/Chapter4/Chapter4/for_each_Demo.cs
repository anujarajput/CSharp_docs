﻿using System;

namespace Chapter4
{
    class for_each_Demo
    {
        static void Main()
        {
            string[] arr = { "AB", "abc", "gf", "ttere", "po", "HGFA" };
            
            foreach(string temp in arr)
            {
                Console.WriteLine(temp);
            }

            Console.ReadLine();

        }
    }
}
