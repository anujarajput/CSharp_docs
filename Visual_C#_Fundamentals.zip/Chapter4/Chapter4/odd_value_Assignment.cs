﻿using System;

namespace Chapter4
{
    class odd_value_Assignment
    {
        static void Main()
        {
            int[] arr = { 37, 25, 34, 12, 7, 39, 34, 25, 13, 75 };
            foreach(int temp in arr)
            {
                if(!(temp%2 == 0))
                {
                    Console.WriteLine(temp);
                }
            }

            Console.ReadLine();
        }
    }
}
