﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter4
{
    class while_Demo
    {
        static void Main()
        {
            int i = 1;
            int sum = 0;
            while (i <= 15)
            {
                sum = sum + i;
                Console.WriteLine(sum);
                i++;
            }

            Console.ReadLine();
        }
    }
}
