﻿using System;
using System.Collections;

namespace Chapter5
{
    class Arraylist_Demo
    {
        static void Main()
        {
            ArrayList std = new ArrayList();
            std.Add(100);
            std.Add("ABC");
            std.Add("abc.nmn@email.com");
            std.Add('M');
            std.Add(true);
            
            Console.WriteLine("Total count:{0}",std.Count);
            Console.WriteLine("Capacity:{0}", std.Capacity);
            std.Capacity = std.Count;
            Console.WriteLine("Changes Capacity:{0}", std.Capacity);
            foreach (var temp in std)
            {
                Console.WriteLine(temp);
            }
            Console.WriteLine("----------------------------------");
            Console.WriteLine("Remove property");
            std.Remove("ABC");
            Console.WriteLine("Count:{0},Capacity:{0}", std.Count, std.Capacity);
            foreach (var temp in std)
            {
                Console.WriteLine(temp);
            }

            Console.WriteLine("---------------------------------");
            Console.WriteLine("using contains method for 100:{0}", std.Contains(100));

            Console.WriteLine("---------------------------------");
            Console.WriteLine("clear method");
            std.Clear();
            Console.WriteLine("Count:{0},Capacity:{0}", std.Count, std.Capacity);


            Console.ReadLine();

        }
    }
}
