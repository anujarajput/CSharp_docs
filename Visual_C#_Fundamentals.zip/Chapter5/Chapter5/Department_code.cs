﻿using System;
using System.Collections.Generic;

namespace Chapter5
{
    class Department_code
    {
        public int dept_code { get; set; }
    }
}
