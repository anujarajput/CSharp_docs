﻿using System;
using System.Collections.Generic;

namespace Chapter5
{
    class Dictionary_Demo
    {
        static void Main()
        {
            Dictionary<int, string> d = new Dictionary<int, string>();

            d.Add(1004,"ABC");
            d.Add(1001, "PQR");
            d.Add(1005, "XYZ");
            d.Add(1007, "MNP");
            d.Add(1003, "HGF");
            d.Add(1006, "TYU");
            d.Add(1002, "ERT");

            Console.WriteLine($"Count:{d.Count}");
            Console.WriteLine($"Element:{d[1004]}");
            
            foreach(int temp in d.Keys)
            {
                Console.WriteLine($"Key:{temp}, Value:{d[temp]}");
            }
            
            

            Console.ReadLine();
        }
    }
}
