﻿using System;
using System.Collections.Generic;

namespace Chapter5
{
    class Employee_Dictionary
    {
        static void Main()
        {
            Dictionary<Department_code, Employee_details> emp = new Dictionary<Department_code, Employee_details>()
            {
                { new Department_code{dept_code=1002 }, new Employee_details{emp_code=53124, emp_name="HAGR JKSSG", dept_code=1002 } },
                { new Department_code{dept_code=1002 }, new Employee_details{emp_code=54736, emp_name="OTSYR YTSGS", dept_code=1002 } },
                { new Department_code{dept_code=1004 }, new Employee_details{emp_code=3547, emp_name="UYTSH MJGS", dept_code=1004 } },
                { new Department_code{dept_code=1001 }, new Employee_details{emp_code=351, emp_name="OIYT KJJHG", dept_code=1001 } },
                { new Department_code{dept_code=1005 }, new Employee_details{emp_code=68425, emp_name="IIUTH", dept_code=1005 } },
                { new Department_code{dept_code=1005 }, new Employee_details{emp_code=69854, emp_name="IUYTH", dept_code=1005 } },
                { new Department_code{dept_code=1001 }, new Employee_details{emp_code=452, emp_name="HTDS THAA", dept_code=1001 } },
                { new Department_code{dept_code=1003 }, new Employee_details{emp_code=4125, emp_name="KHTYY POI", dept_code=1003 } },
                { new Department_code{dept_code=1004 }, new Employee_details{emp_code=35841, emp_name="RTES POTRE", dept_code=1004 } }
            };

            Console.WriteLine("Department | Employee Details");
            foreach(var temp in emp.Keys)
            {
               Console.WriteLine( $"{temp.dept_code} | {emp[temp].emp_code} {emp[temp].emp_name}");
            }


            Console.ReadLine();
        }
    }
}
