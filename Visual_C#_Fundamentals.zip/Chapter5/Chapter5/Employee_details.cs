﻿using System;
using System.Collections.Generic;

namespace Chapter5
{
    class Employee_details
    {
        public int emp_code { get; set; }
        public string emp_name { get; set; }
        public int dept_code { get; set; }
    }
}
