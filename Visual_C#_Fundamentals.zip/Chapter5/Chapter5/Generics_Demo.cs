﻿using System;
using System.Collections.Generic;
namespace Chapter5
{
    class Generics_Demo
    {
        static void Main()
        {
            Queue<int> que = new Queue<int>();
            que.Enqueue(101);
            que.Enqueue(102);
            que.Enqueue(103);
            que.Enqueue(104);
            que.Enqueue(105);

            Stack<int> stk = new Stack<int>();
            stk.Push(101);
            stk.Push(102);
            stk.Push(103);
            stk.Push(104);
            stk.Push(105);
        }
    }
}
