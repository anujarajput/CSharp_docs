﻿using System;
using System.Collections;

namespace Chapter5
{
    class Hash_Demo
    {
        static void Main()
        {
            Hashtable htbl = new Hashtable();
            htbl.Add("mh", 27);
            htbl.Add("gj", 24);
            htbl.Add("rj", 26);
            htbl.Add("mp", 34);
            htbl.Add("up", 20);
            //Console.WriteLine("Enter state name for Code:");
            //string state = Console.ReadLine();
            string state = "GJ";
            Console.WriteLine("Code for state {0}:{1}", state, htbl[state.ToLowerInvariant()]);

            htbl["mp"] = 29;
            Console.WriteLine("Changed code for state MP:{0}", htbl[("mp").ToLowerInvariant()]);
            foreach(var temp in htbl.Keys)
            {
                Console.WriteLine("Key:{0}, val:{1}", temp, htbl[temp]);
            }
            Console.WriteLine("Remove method:");
            htbl.Remove("rj");
            foreach (var temp in htbl.Keys)
            {
                Console.WriteLine("Key:{0}, val:{1}", temp, htbl[temp]);
            }
            Console.WriteLine("Count:{0}", htbl.Count);


            Console.ReadLine();
            
        }
    }
}
