﻿using System;
using System.Collections.Generic;

namespace Chapter5
{
    class List_Demo
    {

        static  void Main()
        {
            //List<int> list = new List<int>();
            IList<int> list = new List<int>();
            list.Add(69);
            list.Add(7);
            list.Add(42);
            list.Add(36);
            
            foreach (int temp in list)
            {
                Console.WriteLine(temp);
            }

            Console.WriteLine($"Count:{list.Count}");
            if(list.Remove(42)){
                Console.WriteLine("Element removed");
                foreach (int temp in list)
                {
                    Console.WriteLine(temp);
                }
            }
            else
            {
                Console.WriteLine("No element fount");
            }
            Console.ReadLine();
        }
    }
}
