﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class Program
    {
        static void Main(string[] args)
        {
            //declaration of arrays

            //int[] num1 = { 10, 36, 45, 74, 96 };
            //
            int[] num2 = new int[] { 35, 2, 87, 69, 54 };  //using new keyword
            int[] num3 = new int[5];
            Console.WriteLine("How many elemets needed in array:");
            int ele_no= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Please enter array elemets");
            for (int i=0; i<=ele_no; i++)
            {
                num3[i] =Convert.ToInt32(Console.ReadLine());

            }
            Console.WriteLine(num3);

            Console.ReadLine();

        }
    }
}
