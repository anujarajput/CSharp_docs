﻿using System;
using System.Collections.Generic;

namespace Chapter5
{
    class Sortedlist_Demo
    {
        static void Main()
        {
            SortedList<int, string> s = new SortedList<int, string> {
                { 1004, "ABC" }, { 1001, "PQR" },
                { 1005, "XYZ" }, { 1007, "MNP" },
                { 1003, "HGF" }, { 1006, "TYU" },
                { 1002, "ERT" }
            };

            Console.WriteLine($"Count:{s.Count}");

            foreach (int temp in s.Keys)
            {
                Console.WriteLine($"Key:{temp}, Value:{s[temp]}");
            }

            Console.WriteLine($"Remove:");
            if (s.Remove(1003))
            {
                Console.WriteLine("Element removed");
                foreach (int temp in s.Keys)
                {
                    Console.WriteLine($"Key:{temp}, Value:{s[temp]}");
                }
            }
            else
            {
                Console.WriteLine("No element fount");
            }

            Console.ReadLine();
        }
    }
}
