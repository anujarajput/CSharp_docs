﻿using System;
using System.Collections.Generic;

namespace Chapter5
{
    class Student
    {
        public int s_no { get; set; }
        public string s_name { get; set; }

    }
}
