﻿using System;
using System.Collections.Generic;

namespace Chapter5
{
    class StudentCollection_Demo
    {
        static void Main()
        {
            List<Student> st = new List<Student>()
            {
                new Student{s_no=101,s_name="GFD"},
                new Student{s_no=104,s_name="FDSD"},
                new Student{s_no=105,s_name="RES"},
                new Student{s_no=110,s_name="VSEAS"},
                new Student{s_no=103,s_name="EWQD"},
                new Student{s_no=107,s_name="MDHIUFH"},
                new Student{s_no=102,s_name="BDFV"}
            };

            foreach(Student temp in st)
            {
                Console.WriteLine($"Student Roll no:{temp.s_no} Student Name:{temp.s_name}");
            }


            Console.ReadLine();

        }
    }
}
