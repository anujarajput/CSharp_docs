﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class array_class_Demo
    {
        static void Main()
        {
            int[] arr1 = { 35, 45, 11, 25, 87, 1, 65 };
            foreach (int temp in arr1)
            {
                Console.Write("{0}\t",temp);
            }
            Console.WriteLine();

            int[] arr2 = new int[10];
            int[,] arr3 = new int[2, 3];
            int[] arr4 = new int[5];

            arr1.CopyTo(arr2, 0);
            Console.WriteLine("copyTo");
            foreach (int temp in arr2)
            {
                Console.Write("{0}\t", temp);
            }
            Console.WriteLine();

            Console.WriteLine("--------------------------------------------");
            Console.WriteLine("Lowerbound for arr1:{0}", arr1.GetLowerBound(0));
            Console.WriteLine("Upperbound for arr1:{0}", arr1.GetUpperBound(0));
            Console.WriteLine("Lowerbound for arr2:{0}", arr2.GetLowerBound(0));
            Console.WriteLine("Upperbound for arr2:{0}", arr2.GetUpperBound(0));
            Console.WriteLine("Upperbound for arr3(0):{0}", arr3.GetUpperBound(0));
            Console.WriteLine("Upperbound for arr3(1):{0}", arr3.GetUpperBound(1));
            Console.WriteLine("--------------------------------------------");

            Console.WriteLine("Numbers of dimensions of arr1:{0}",arr1.Rank);
            Console.WriteLine("Numbers of dimensions of arr2:{0}",arr2.Rank);
            Console.WriteLine("Numbers of dimensions of arr3:{0}",arr3.Rank);
            Console.WriteLine("--------------------------------------------");

            Console.WriteLine("Array methods:");
            Console.WriteLine("Copy arr1 to arr4");

            Array.Copy(arr1, arr4, 4);
            foreach (int temp in arr4)
            {
                Console.Write("{0}\t", temp);
            }
            Console.WriteLine();

            Console.WriteLine("sorted arr1");
            Array.Sort(arr1);
            foreach (int temp in arr1)
            {
                Console.Write("{0}\t", temp);
            }
            Console.WriteLine();

            Console.WriteLine("IndexOf element 87 in arr1:{0}", Array.IndexOf(arr1, 87));

            Console.WriteLine("reverse of arr1");
            Array.Reverse(arr1);
            foreach (int temp in arr1)
            {
                Console.Write("{0}\t", temp);
            }
            Console.WriteLine();


            Console.WriteLine("--------------------------------------------");

            Console.ReadLine();
        }
    }
}
