﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class jagged_array_Demo
    {
        static void Main()
        {
            // Jagged array is also known as arrays of array

            int[][] num1 = new int[2][];//size of columns are not initialized
            num1[0] = new int[3] { 10, 20, 30 };
            num1[1] = new int[2] { 60, 25 };

            for(int i=0; i<2; i++)
            {
                foreach(int temp in num1[i])
                {
                    Console.Write("{0}\t", temp);
                }
                Console.WriteLine();
            }

            Console.ReadLine();
        }
    }
}
