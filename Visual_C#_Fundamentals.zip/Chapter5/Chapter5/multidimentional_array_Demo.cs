﻿using System;

namespace Chapter5
{
    class multidimentional_array_Demo
    {
        static void Main()
        {

            //two dimentional array

            int[,] num1 = { { 25, 36, 74, 35 }, { 65, 1, 45, 34 } };

            int[,] num2 = new int[,] { { 25, 36, 74, 35 }, { 65, 1, 45, 34 } };

            int[,] num3 = new int[2, 3];

            for(int i=0; i<2; i++)
            {
                for(int j=0; j<3; j++)
                {
                    Console.Write("{0}\t",num2[i, j]);
                }
                Console.WriteLine();
            }
            Console.ReadLine();

        }
    }
}
