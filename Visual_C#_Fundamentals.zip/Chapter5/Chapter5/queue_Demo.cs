﻿using System;
using System.Collections;

namespace Chapter5
{
    class queue_Demo
    {
        static void Main()
        {
            Console.WriteLine("------------------Stack----------------");
            Stack stk = new Stack();
            stk.Push(101);
            stk.Push(102);
            stk.Push(103);
            stk.Push(104);
            stk.Push(105);
            foreach (var temp in stk)
            {
                Console.WriteLine(temp);
            }

            Console.WriteLine("Pop method:"); 
            stk.Pop();
            foreach (var temp in stk)
            {
                Console.WriteLine(temp);
            }

            Console.WriteLine("Peek method:"); 
            Console.WriteLine("next ele to be removed:{0}", stk.Peek());

            Console.WriteLine("------------------Queue----------------");
            Queue que = new Queue();
            Console.WriteLine("Enqueue method:");
            que.Enqueue(101);
            que.Enqueue(102);
            que.Enqueue(103);
            que.Enqueue(104);
            que.Enqueue(105);
            foreach(var temp in que)
            {
                Console.WriteLine(temp);
            }

            Console.WriteLine("Dequeue method:");
            que.Dequeue();
            foreach (var temp in que)
            {
                Console.WriteLine(temp);
            }

            Console.WriteLine("Peek method:"); //peek method returns next element to be removed when we use dequeue method.
            Console.WriteLine("next ele to be removed:{0}",que.Peek());



            Console.ReadLine();
        }
    }
}
