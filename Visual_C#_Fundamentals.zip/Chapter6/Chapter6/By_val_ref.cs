﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class By_val_ref
    {
        static void Main()
        {
            MyMath m1 = new MyMath();
            int num1 = 30;
            Console.WriteLine("passing by value");
            Console.WriteLine(m1.Increment(num1));
            Console.WriteLine(num1);
            Console.WriteLine("passing by reference");
            Console.WriteLine(m1.Increment(ref num1));
            Console.WriteLine(num1);

            Console.ReadLine();
        }
    }
}
