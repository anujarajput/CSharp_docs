﻿using System;

namespace Chapter6
{
    class Custom_exception_Demo
    {
        static void Main()
        {
            try
            {
                Employee emp = new Employee();
                emp.ValidateEmployee(00);
            }
            catch (InvalidEmployee e)
            {
                Console.WriteLine(e.Message);
            }
            

            Console.ReadLine();
        }
    }
}
