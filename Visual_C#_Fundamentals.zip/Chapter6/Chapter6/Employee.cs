﻿using System;

namespace Chapter6
{
    class Employee
    {
        public void PrintName(string name)
        {
            if(name == "")
            {
                throw new NullReferenceException("Employee name is NULL");
            }
        }

        public void ValidateEmployee(int emp_code)
        {
            if (emp_code <= 0)
            {
                throw new InvalidEmployee();
            }
        }
    }
}
