﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class Exception_Demo
    {
        static void Main()
        {
            MyMath m = new MyMath();

            try
            {

                Console.WriteLine("Enter 1st number:");
                int num1 = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter 2nd number:");
                int num2 = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Sum:{0}", m.Sum(num1, num2));
            }
            catch(FormatException e)
            {
                Console.WriteLine("Error occoured:{0}",e.Message);
            }
            catch (DivideByZeroException e)
            {
                Console.WriteLine("Error occoured:{0}", e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error occoured:{0}", e.Message);
            }
            finally
            {
                Console.WriteLine("Finally block....");
                GC.Collect();
            }


            Console.ReadLine();

        }
    }
}
