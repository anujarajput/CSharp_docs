﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class Function_as_parameter
    {
        static void Main()
        {
            MyMath m = new MyMath();
            Console.WriteLine("Normal Parameter");
            int[] mymarks = { 36, 54, 85, 65 };
            m.Marks1(mymarks);

            MyMath m2 = new MyMath();
            Console.WriteLine("Passing function as Parameter");
            m2.Marks2(36, 54, 85, 65);

            Console.ReadLine();
        }
    }
}
