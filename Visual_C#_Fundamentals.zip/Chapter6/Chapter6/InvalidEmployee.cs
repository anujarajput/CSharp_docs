﻿using System;

namespace Chapter6
{
    class InvalidEmployee:Exception
    {
        public InvalidEmployee():base("Invalid Employee code")
        {


        }
    }
}
