﻿using System;

namespace Chapter6
{
    class Invalid_student:Exception
    {
        public Invalid_student():base("Invalid Student Information. Please enter valid Student Details")
        {

        }
    }
}
