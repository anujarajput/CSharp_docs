﻿using System;

namespace Chapter6
{
    class MyMath
    {
        //function declaration

        public void Message()
        {
            Console.WriteLine("This is message..");
        }

        public int Sum(int num1, int num2)
        {
            return num1 / num2;
        }

        //function overloading
        public double Sum(double d1, double d2)
        {
            return d1 + d2;
        }

        //by value parameters and by reference parameters

        public int Increment(int x)
        {
            x++;
            return x;
        }
        public int Increment(ref int x)
        {
            x++;
            return x;
        }

        public int MyFunction(out int x)
        {
            x = 10;
            int y = 100;
            return y;
        }

        public int OutFunction(out int x1, out int x2, int x3)
        {
            x1 = x3;
            x2 = 100;
            int sum = 40;
            return sum;
        }

        public double OutGst(out double gstamount, double prod_amount, double gst_prct)
        {
            gstamount = prod_amount * (gst_prct / 100);
            double totalamount = prod_amount + gstamount;
            return totalamount;

        }

        public int Size(int height, int width = 1)
        {
            return height * width;
        }

        public string Size_format(int height, int width = 1, string msg="Size is:")
        {
            return string.Format("{0} {1}", msg, (height * width));
        }

        public void Marks1(int[] marks)
        {
            foreach(int temp in marks)
            {
                Console.WriteLine(temp);
            }

            Console.ReadLine();
        }
        public void Marks2( params int[] marks)
        {
            foreach(int temp in marks)
            {
                Console.WriteLine(temp);
            }

            Console.ReadLine();
        }

        public void RecFun(int x)
        {
            if (x <= 10)
            {
                Console.WriteLine(x);
                x++;
                RecFun(x);
            }

            Console.ReadLine();
        }

        
    }
}
