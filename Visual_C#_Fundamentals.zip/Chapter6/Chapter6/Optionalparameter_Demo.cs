﻿using System;

namespace Chapter6
{
    class Optionalparameter_Demo
    {
        static void Main()
        {
            MyMath m = new MyMath();
            Console.WriteLine("Optional Parameter");
            Console.WriteLine("Size:{0}", m.Size(20));
            Console.WriteLine("Size:{0}", m.Size(20,4));

            Console.WriteLine("Named Parameter");
            Console.WriteLine(m.Size_format(20));
            Console.WriteLine(m.Size_format(20, msg:"This is Answer:"));


            Console.ReadLine();
        }

    }
}
