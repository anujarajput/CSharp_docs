﻿using System;

namespace Chapter6
{
    class Out_Demo
    {
        static void Main()
        {
            MyMath m = new MyMath();
            //int n1, n2;
            //Console.WriteLine(m.OutFunction(out n1, out n2, 20 ));
            //Console.WriteLine(n1);
            //Console.WriteLine(n2);

            double amount;            
            Console.WriteLine("Total Amount to be paid:{0}", m.OutGst(out amount, 50000, 5));
            Console.WriteLine("GST applicable on your amount:{0}", amount);
            Console.ReadLine();
        }
    }
}
