﻿using System;

namespace Chapter6
{
    class Program
    {
        static void Main(string[] args)
        {
            MyMath m = new MyMath();
            m.Message();
            int addition = m.Sum(42, 56);
            Console.WriteLine(addition);

            Console.ReadLine();

        }
    }
}
