﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class Recursive_function
    {
        static void Main()
        {
            MyMath m = new MyMath();

            m.RecFun(2);
        }
    }
}
