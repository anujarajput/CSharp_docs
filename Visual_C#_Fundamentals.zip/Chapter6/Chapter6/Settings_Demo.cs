﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class Settings_Demo
    {
        static void Main()
        {
            Login();
            UserDetails();
        }

        public static void Login()
        {
            Chapter6.Properties.Settings1.Default.Username = "ABC";
        }
        public static void UserDetails()
        {
            string uname = Chapter6.Properties.Settings1.Default.Username;
            Console.WriteLine("Welcome:{0}", uname);

            Console.ReadLine();
        }
    }
}
