﻿using System;

namespace Chapter6
{
    class Student_Validation
    {

        public void Validate_Student(int roll_no, string name)
        {
            if ((roll_no < 100) || (name == ""))
            {
                throw new Invalid_student();
            }
            else
            {
                Console.WriteLine("Student Roll No:{0}, Student Name:{1}", roll_no, name);
            }
        }
    }
}
