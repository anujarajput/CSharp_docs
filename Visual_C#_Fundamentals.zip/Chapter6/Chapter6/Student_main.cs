﻿using System;

namespace Chapter6
{
    class Student_main
    {
        static void Main()
        {
            try
            {
                Console.WriteLine("please enter student roll number:");
                int sroll = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("please enter student Name:");
                string sname = Console.ReadLine();

                Student_Validation std = new Student_Validation();
                std.Validate_Student(sroll, sname);
            }
            catch(Invalid_student e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadLine();
        }
    }
}
