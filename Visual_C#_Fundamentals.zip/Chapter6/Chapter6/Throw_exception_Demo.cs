﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class Throw_exception_Demo
    {
        static void Main()
        {

            try
            {
                Employee emp = new Employee();

                emp.PrintName("");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            

            Console.ReadLine();
        }
    }
}
