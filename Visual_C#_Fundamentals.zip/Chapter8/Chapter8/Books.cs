﻿using System;

namespace Chapter8
{
    class Books
    {
        int PI = 30;
        string str = "abc";
    }

    struct Book
    {
        int PI;
        string book_name;
        string book_auther;
        public Book(int PI, string book_name, string book_auther)
        {
            this.PI = PI;
            this.book_name = book_name;
            this.book_auther = book_auther;
        }
        public string Display()
        {
            return string.Format("Book no={0}, Name={1}, Auther={2}", PI, book_name, book_auther);
        }
    }
}
