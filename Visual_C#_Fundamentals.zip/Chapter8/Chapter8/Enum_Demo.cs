﻿using System;

namespace Chapter8
{
    enum Enum_Demo
    {
        red,green,blue,pink=100,white
    }
    enum Color1
    {
        red=Enum_Demo.green,green=100,blue=Enum_Demo.blue,pink=Enum_Demo.pink,white=20
    }
    enum State_code
    {
        mh=2015,gj=456,mo=7564,up=4562,rj=2147,ap=417
    }
}
