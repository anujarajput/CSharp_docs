﻿using System;
namespace Chapter8
{
    class Enum_main
    {
        static void Main()
        {
            //print enum member
            Console.WriteLine(Enum_Demo.green);
            //print enum member value
            Console.WriteLine(Enum_Demo.green.GetHashCode());
            Console.WriteLine(Convert.ToInt32(Enum_Demo.green));

            Console.WriteLine("state code:{0}", State_code.gj.GetHashCode());

            //print all enum members
            Console.WriteLine("State in enum");
            foreach (string state in Enum_Demo.GetNames(typeof(State_code)))
            {
                Console.WriteLine(state);
            }
            //print all enum members value
            Console.WriteLine("Values for enum states");
            foreach (int val in Enum_Demo.GetValues(typeof(State_code)))
            {
                Console.WriteLine(val);
            } 

            Console.ReadLine();
        }
    }
}
