﻿using System;

namespace Chapter8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter book no:");
            int PI = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter book name:");
            string book_name = Console.ReadLine();
            Console.WriteLine("Enter book auther name:");
            string book_auther = Console.ReadLine();
            

            Book bk = new Book(PI, book_name, book_auther);
            Console.WriteLine(bk.Display());

            Console.ReadLine();

        }
    }
}
