﻿using System;

namespace Chapter8
{
    
    struct MyDate
    {
        public struct MyMonth
        {
            public enum Months
            {
                jan=1,feb=2,mar=3,apr=4,may=5,jun=6,jul=7,aug=8,sep=9,oct=10,nov=11,dec=12
            }
        }
        public struct MyYear
        {
            public enum Years
            {
                year1=2001,year2=2002,year3=2003,year4=2004
            }
        }
    }
}
