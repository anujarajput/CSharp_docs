﻿using System;

namespace Chapter8
{
    class Structure_enum_main
    {
        static void Main()
        {
            Console.WriteLine($"Date:{ MyDate.MyMonth.Months.jan}/{ MyDate.MyYear.Years.year3.GetHashCode()}");

            Console.WriteLine("All Month");
            foreach (string month in Enum.GetNames(typeof(MyDate.MyMonth.Months)))
            {
                Console.WriteLine(month);
            }

            Console.WriteLine("All Year");
            foreach (string yr in Enum.GetNames(typeof(MyDate.MyYear.Years)))
            {
                Console.WriteLine(yr);
            }

            Console.ReadLine();
        }
    }
}
