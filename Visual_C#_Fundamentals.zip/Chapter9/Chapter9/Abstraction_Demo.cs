﻿using System;

namespace Chapter9
{
    class Abstraction_Demo
    {
        int model_no;
        string model_name;
        int IMEI_no;

        public Abstraction_Demo()
        {
            Console.WriteLine("Default contructor of Abstraction_Demo");
        }
        public Abstraction_Demo(int model_no, string model_name, int IMEI_no)
        {
            this.model_no = model_no;
            this.model_name = model_name;
            this.IMEI_no = IMEI_no;
        }

        public string AboutProduct()
        {
            return string.Format($"Model No:{model_no}, Model Name:{model_name}, IMEI no:{IMEI_no}");
        }

        public string Calling()
        {
            return string.Format($"Calling from Abstraction_Demo");
        }

        public string SMS()
        {
            return string.Format($"SMS from Abstraction_Demo");
        }

        public override string ToString()
        {
            return string.Format($"Model No:{model_no}, Model Name:{model_name}, IMEI no:{IMEI_no}");
        }

        ~Abstraction_Demo()
        {
            Console.WriteLine("Destructor of Abstraction_Demo...");
        }
    }
}
