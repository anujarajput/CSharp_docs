﻿using System;

namespace Chapter9
{
    class Static_Demo
    {
        static void Main()
        {

        }
    }

    static class Employee
    {
        static Employee()
        {
            Console.WriteLine("default contructor of Employee");
        }

        public static string Details(int emp_code, string emp_name)
        {
            return string.Format($"Employee code:{emp_code}, Employee Name:{emp_name}");
        }
    }

    
}
