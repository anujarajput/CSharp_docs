﻿using System;

namespace Chapter9
{
    class Hirarchical_inheritance_Demo:Inheritance_Demo
    {
        public Hirarchical_inheritance_Demo()
        {
            Console.WriteLine("Default constructor of Hirarchical_inheritance_Demo");

        }

        public string Mail()
        {
            return string.Format($"Mailing from Hirarchical_inheritance_Demo");
        }
        public string Camera()
        {
            return string.Format($"Camera from Hirarchical_inheritance_Demo");
        }

        
    }
}
