﻿using System;

namespace Chapter9
{
    class Hirarchical_main
    {
        static void Main()
        {
            Calling_methods();
        }

        public static void Calling_methods()
        {
            Hirarchical_inheritance_Demo obj = new Hirarchical_inheritance_Demo();
            Console.WriteLine(obj.Calling());
            Console.WriteLine(obj.SMS());
            Console.WriteLine(obj.Mail());
            Console.WriteLine(obj.Camera());

            Console.ReadLine();
        }
    }
}
