﻿using System;

namespace Chapter9
{
    interface IWIFI
    {
        string StartWIFI();
        string StopWIFI();
    }

    class Mobile:Abstraction_Demo, IWIFI
    {
        public string StartWIFI()
        {
            return "Starting Wifi";
        }
        public string StopWIFI()
        {
            return "Stopping Wifi";
        }
    }

    class Mobile2: Mobile
    {
        public string Message()
        {
            return "Message from Mobile2";
        }
    }

    class Interface_Demo
    {
        static void Main()
        {
            //IWIFI i = new Mobile();
            //Console.WriteLine(i.StartWIFI());
            //Console.WriteLine(i.StopWIFI());


            //implicite implimentation

            Mobile m = new Mobile();
            Console.WriteLine(m.StartWIFI());
            Console.WriteLine(m.StopWIFI());
            Console.WriteLine("--------------------");

            //multilevel 
            Mobile2 m2 = new Mobile2();
            Console.WriteLine(m2.Message());
            Console.WriteLine(m2.StartWIFI());
            Console.WriteLine(m2.StopWIFI());

            Console.ReadLine();
        }
    }
}
