﻿using System;

namespace Chapter9
{
    class Inheritance_Demo: Abstraction_Demo  //here Inheritance_Demo class inheriting Abstraction_Demo class 
    {

        public Inheritance_Demo()
        {
            Console.WriteLine("Default Constructor of Inheritance_Demo");
        }

        ~Inheritance_Demo()
        {
            Console.WriteLine("Destructor of Inheritance_Demo");
        }
    }
}
