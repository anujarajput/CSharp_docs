﻿using System;

namespace Chapter9
{
    class Inheritance_main
    {
        static void Main()
        {
            Calling_methods();
        }

        public static void Calling_methods()
        {
            Multilevel_inheritance_Demo obj = new Multilevel_inheritance_Demo();
            obj.Mail();
            obj.Music();
            obj.Calling();
            obj.SMS();
        }
    }
}
