﻿using System;

namespace Chapter9
{
    class Multilevel_inheritance_Demo:SingleInheritance_Demo
    {
        public Multilevel_inheritance_Demo()
        {
            Console.WriteLine("Default constructor of Multilevel_inheritance_Demo");
        }

        public string Music()
        {
            return string.Format($"Music from Multilevel_inheritance_Demo");
        }

    }
}
