﻿using System;
namespace Chapter9
{
    class MyMath
    {
        //Function overloading
        public int Add(int num1, int num2)
        {
            return num1 + num2;
        }

        public string Add(string str1, string str2)
        {
            return str1 + str2;
        }

        //Function overriding(virtual functions)
        public virtual int Increment(int x)
        {
            x++;
            return x;
        }
    }

    class MyMath2 : MyMath
    {
        //overriding
        public override int Increment(int x)
        {
            x = x + 10;
            return x;
        }
        
        public double Add(double num1, double num2)
        {
            return num1 + num2;
        }
    }

    class MyMath3 : MyMath2
    {
        //sealed keyword to finalize the overriden dunction
        public sealed override int Increment(int x)
        {
            x = x + 100;
            return x;
        }
    }
}
