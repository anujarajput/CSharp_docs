﻿using System;

namespace Chapter9
{
    class Overloading_demo
    {
        static void Main()
        {
            MyMath m = new MyMath();

            Console.WriteLine(m.Add(20, 30));
            Console.WriteLine(m.Add("Abc", "pQr"));

            Console.ReadLine();            
        }
    }
}
