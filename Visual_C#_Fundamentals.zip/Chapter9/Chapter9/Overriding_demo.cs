﻿using System;

namespace Chapter9
{
    class Overriding_demo
    {
        static void Main()
        {
            MyMath2 m = new MyMath2();
            Console.WriteLine(m.Increment(10));
            Console.WriteLine(m.Add(10, 10));

            Console.ReadLine();
        }
    }
}
