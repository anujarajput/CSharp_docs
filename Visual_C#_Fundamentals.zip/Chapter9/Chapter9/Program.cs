﻿using System;

namespace Chapter9
{
    class Program
    {
        static void Main(string[] args)
        {
            CreateInstance();
            GC.Collect();

            Console.ReadLine();
        }

        public static void CreateInstance()
        {
            Abstraction_Demo abs = new Abstraction_Demo();

            Console.WriteLine("Enter model no:");
            int model_no = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter model name:");
            string model_name = Console.ReadLine();
            Console.WriteLine("Enter IMEI no:");
            int IMEI_no = Convert.ToInt32(Console.ReadLine());

            Abstraction_Demo abs1 = new Abstraction_Demo(model_no, model_name, IMEI_no);
            Console.WriteLine(abs1.AboutProduct());

            //Console.WriteLine(abs1.ToString());//virtual function


        }
    }
}
