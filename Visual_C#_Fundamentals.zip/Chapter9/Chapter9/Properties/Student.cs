﻿using System;
namespace Chapter9.Properties
{
    class Student
    {
        private int roll_no;
        private string name;

        public int Std_roll_no
        {
            get
            {
                return roll_no;
            }

            set
            {
                roll_no = value;
            }
        }
        public string Std_name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }
    }
}
