﻿using System;

namespace Chapter9
{
    class Property_Demo
    {
        static void Main()
        {
            Student std = new Student();
            std.Std_roll_no = 12;
            std.Std_name = "shjd";
            //std.School_name = "dhfsjd";

            Console.WriteLine($"{std.Std_roll_no} {std.Std_name}");

            //auto property initializer
            Student std2 = new Student() { Std_roll_no = 25, Std_name = "hgfvf" };

            Console.WriteLine($"{std.Std_roll_no} {std.Std_name}");

            Console.ReadLine();
        }
    }
}
