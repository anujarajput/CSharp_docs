﻿using System;

namespace Chapter9
{
    class SingleInheritance_Demo:Inheritance_Demo
    {
        static void Main()
        {
            Create();
            GC.Collect();
            Console.ReadLine();

        }

        public string Mail()
        {
            return string.Format($"Mailing from SingleInheritance_Demo");
        }

        public static void Create()
        {
            Inheritance_Demo obj1 = new Inheritance_Demo();

            obj1.AboutProduct();
            obj1.Calling();
            obj1.SMS();
        }
    }
}
