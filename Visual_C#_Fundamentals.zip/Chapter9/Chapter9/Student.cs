﻿using System;

namespace Chapter9
{
    class Student
    {
        
        private int roll_no;
        private string name;
        private string school_name;

        public int Std_roll_no
        {
            get
            {
                return roll_no;
            }

            set
            {
                if (value <= 0)
                {
                    Console.WriteLine("Invalid Roll no");
                }
                else
                {
                    roll_no = value;
                }
                
            }
        }
        public string Std_name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }
        /// <summary>
        /// School name Can not be changed.
        /// </summary>
        public string School_name
        {
            get
            {
                return "ABCD";
            }
        }
    }
}
