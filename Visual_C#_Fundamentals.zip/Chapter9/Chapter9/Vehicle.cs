﻿using System;

namespace Chapter9
{
    abstract class Vehicle
    {

        public Vehicle()
        {
            Console.WriteLine("Default contructor of Vehicle");
        }

        public string Start()
        {
            return "Starting Vehicle";
        }
        public string Stop()
        {
            return "Stoping Vehicle";
        }
        public abstract string Type(string type);
    }

    class Car : Vehicle
    {
        public override string Type(string type)
        {
            return $"Start type:{type}";
        }
    }

    class Vehicle_main
    {
        static void Main()
        {
            Car c = new Car();
            Console.WriteLine(c.Start());
            Console.WriteLine(c.Stop());
            Console.WriteLine(c.Type("key"));

            Console.ReadLine();
        }
    }

}
