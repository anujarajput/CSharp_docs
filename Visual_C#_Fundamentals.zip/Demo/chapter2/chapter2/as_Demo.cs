﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter2
{
    class as_Demo
    {
        static void Main()
        {
            object[] arr = { 35, "abcd", 36, 75, "sgd" };
            string str = arr[1] as string;
            Console.WriteLine(str);

            //as do not support value type variables it can be only work with reference type variables.

            Console.ReadLine();
        }
    }
}
