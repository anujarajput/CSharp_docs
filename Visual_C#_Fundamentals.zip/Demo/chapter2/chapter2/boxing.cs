﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter2
{
    class boxing
    {
        static void Main()
        {
            int num = 58;
            Object obj = num;

            Console.WriteLine(obj);

            Console.ReadLine();
        }
    }
}
