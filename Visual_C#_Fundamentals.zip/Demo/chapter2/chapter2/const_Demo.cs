﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter2
{
    class const_Demo
    {
        static void Main()
        {
            //Constant variables must initialize at time of declaration and we can not be reassigned.

            const double PI = 3.14;
            int r = 10;
            double aoc = r * r * PI;

            Console.WriteLine(aoc);

            Console.ReadLine();
        }
    }
}
