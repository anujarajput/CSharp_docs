﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter2
{
    class dynamic_Demo
    {
        static void Main()
        {
            //You can not just define dynamic variables, assignment of value is mandatory at time of declaration

            dynamic variable1 = 366;
            Console.WriteLine(variable1.GetType());

            dynamic variable2 = "abcd";
            Console.WriteLine(variable2.GetType());

            Console.ReadLine();
        }
    }
}
