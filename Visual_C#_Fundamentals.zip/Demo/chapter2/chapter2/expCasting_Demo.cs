﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter2
{
    class expCasting_Demo
    {
        static void Main()
        {
            //there are two ways of explecite typecasting

            // 1.Syntextual explicite typecasting: In this way data might be lost
            double dbl1 = 65.8;
            int num1 = (int)dbl1;

            Console.WriteLine(num1);

            //2. In this way values can be rounded as a result

            double dbl2 = 65.8;
            int num2 = Convert.ToInt32(dbl2);

            Console.WriteLine(num2);

            Console.ReadLine();
        }
    }
}
