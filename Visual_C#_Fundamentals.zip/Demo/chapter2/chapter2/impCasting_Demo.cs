﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter2
{
    class impCasting_Demo
    {
        static void Main()
        {
            //Implecite typecating is done by compiler.

            int num = 50;
            double dbl = num;

            Console.WriteLine(dbl);

            Console.ReadLine();
        }
    }
}
