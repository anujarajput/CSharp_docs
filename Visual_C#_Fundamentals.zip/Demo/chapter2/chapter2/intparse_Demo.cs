﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter2
{
    class intparse_Demo
    {
        static void Main()
        {
            Console.WriteLine("Please enter a number:");
            string str = Console.ReadLine();
            int num = int.Parse(str);

            Console.WriteLine(num);

            Console.ReadLine();
        }
    }
}
