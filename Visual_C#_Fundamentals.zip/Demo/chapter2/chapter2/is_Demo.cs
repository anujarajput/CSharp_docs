﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter2
{
    class is_Demo
    {
        static void Main()
        {
            int num1 = 20;
            int num2 = 0;
            Object num3 = 74;
            Console.WriteLine(num1 is int); //True
            Console.WriteLine(num2 is double); //False
            Console.WriteLine(num3 is int); //True
            Console.WriteLine();

            typeof_Demo obj1 = new typeof_Demo();
            Custom_Class obj2 = new Custom_Class();
            Console.WriteLine(obj2 is typeof_Demo); //True
            Console.WriteLine(obj1 is Custom_Class); //False

            Console.ReadLine();
        
        }
    }
}
