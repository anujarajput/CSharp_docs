﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter2
{
    class object_Demo
    {
        static void Main()
        {
            object obj1 = 30, obj2 = "string", obj3 = 53.9, obj4 = false, obj5 = "J";
            Console.WriteLine("obj1 = {0}\t obj2 = {1}\t obj3 = {2}\t obj4 = {3}\t obj5 = {4}",obj1, obj2, obj3, obj4, obj5);

            Console.ReadLine();
        }
    }
}
