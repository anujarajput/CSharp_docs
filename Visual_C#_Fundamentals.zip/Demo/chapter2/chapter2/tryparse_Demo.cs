﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter2
{
    class tryparse_Demo
    {
        static void Main()
        {
            Console.WriteLine("Enter the number:");
            string str = Console.ReadLine();
            int outvar;
            bool Iscomp = int.TryParse(str, out outvar);
            if (Iscomp)
            {
                Console.WriteLine(outvar);
            }
            else
            {
                Console.WriteLine("Conversion id not compatible...");
            }
            Console.ReadLine();
        }

    }
}
