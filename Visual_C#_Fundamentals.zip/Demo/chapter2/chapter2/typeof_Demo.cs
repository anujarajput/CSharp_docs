﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter2
{
    class typeof_Demo
    {
        static void Main()
        {
            Type type1 = typeof(int);
            Type type2 = typeof(long);
            Type type3 = typeof(short);
            Console.WriteLine("int = {0} , Long = {0} , Short = {0}", type1, type2, type3);
            Console.ReadLine();

        }
    }

    class Custom_Class:typeof_Demo
    {

    }
}
