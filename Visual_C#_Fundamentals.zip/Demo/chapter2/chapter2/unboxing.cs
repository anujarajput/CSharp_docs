﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter2
{
    class unboxing
    {
        static void Main()
        {
            Object obj = 63;
            int num = (int)obj;

            Console.WriteLine(num);
            Console.ReadLine();
        }
    }
}
