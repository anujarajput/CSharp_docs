﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter2
{
    class userInput_Demo
    {
        static void Main()
        {
            Console.WriteLine("Please enter 1st number:");
            int num1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Please enter 2nd number:");
            int num2 = Convert.ToInt32(Console.ReadLine());

            int sum = num1 + num2;
            Console.WriteLine("Addition: {0}", sum);

            Console.ReadLine();
        }
    }
}
