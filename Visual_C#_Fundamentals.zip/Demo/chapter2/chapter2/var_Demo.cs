﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter2
{
    class var_Demo
    {
        static void Main()
        {
            var variable1 = 65;
            int[] arr = { 10, 20, 30, 40, 50 };
            var v1 = arr;
            foreach (var temp in v1)
            {
                Console.WriteLine(temp);
            }
            Console.ReadLine();

        }
    }
}
