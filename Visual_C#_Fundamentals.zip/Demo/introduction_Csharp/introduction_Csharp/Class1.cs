﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace introduction_Csharp
{
    class Class1
    {
        Program p = new Program();
        
    }
}
