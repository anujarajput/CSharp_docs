﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/// <summary>
/// XML comment
/// </summary>

namespace introduction_Csharp
{
    class Program
    {
        static void Main(string[] args)
        {
        }

    /// <summary>
    /// This function is to write meassage.
    /// </summary>

    public void Print()
    {
        Console.WriteLine("Hellow world..");
    }
    
        /// <summary>
        /// this function accept text parameter and print it 
        /// </summary>
        /// <param name="str">text parameter</param>
        /// <returns></returns>
    public string Print(string str)
        {
            return str;
        }

    }

}
