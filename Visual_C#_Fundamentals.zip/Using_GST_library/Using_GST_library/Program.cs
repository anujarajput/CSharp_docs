﻿using System;
using GST_library;

namespace Using_GST_library
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter Product Amount");
            double prod_amount = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter GST %");
            double gst_perc = Convert.ToDouble(Console.ReadLine());
            
            GST_Calculation gst_clc = new GST_Calculation();

            gst_clc.Calc_GST(prod_amount, gst_perc);


            Console.ReadLine();
        }
    }
}
