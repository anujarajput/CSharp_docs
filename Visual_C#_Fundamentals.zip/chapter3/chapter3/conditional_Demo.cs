﻿using System;

namespace chapter3
{
    class conditional_Demo
    {
        static void Main()
        {
            Console.WriteLine("Enter qualification(UG | PG):");
            string edu = Console.ReadLine();
            Console.WriteLine("Enter experience(in months):");
            int exp = Convert.ToInt32(Console.ReadLine());

            if (edu == "PG" && exp >= 12)
            {
                Console.WriteLine("Eligible for this position.");
            }
            else
            {
                Console.WriteLine("Not Eligible for this position.");
            }

            Console.ReadLine();
        }
    }
}
