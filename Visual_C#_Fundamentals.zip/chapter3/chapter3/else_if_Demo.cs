﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter3
{
    class else_if_Demo
    {
        static void Main()
        {
            Console.WriteLine("Enter the item to check applicable GST:(Food | Services | Ornaments)");
            string item = Console.ReadLine();

            Console.WriteLine("Enter the amount to check applied GST");
            int amount = Convert.ToInt32(Console.ReadLine());
            double final_amount = 0;

            if (item == "Food")
            {
                Console.WriteLine("Appliacble GST:5%");
                final_amount = amount + (amount * 0.05);
                Console.WriteLine("Amount to pay:{0}", final_amount);
            }
            else if (item == "Services")
            {
                Console.WriteLine("Appliacble GST:4%");
                final_amount = amount + (amount * 0.04);
                Console.WriteLine("Amount to pay:{0}", final_amount);
            }
            else if (item == "Ornaments")
            {
                Console.WriteLine("Appliacble GST:12%");
                final_amount = amount + (amount * 0.12);
                Console.WriteLine("Amount to pay:{0}", final_amount);
            }
            else
            {
                Console.WriteLine("Invalid choice...");
            }
            Console.ReadLine();
        }
    }
}
