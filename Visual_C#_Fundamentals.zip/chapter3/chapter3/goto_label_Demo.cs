﻿using System;

namespace chapter3
{
    class goto_label_Demo
    {
        static void Main()
        {
            int i = 1;
            int sum = 0;
 strt:      if (i<=15)
            {
                sum = sum + i;
                Console.WriteLine(sum);
                i++;
                goto strt;
            }
            Console.ReadLine();
        }
    }
}
