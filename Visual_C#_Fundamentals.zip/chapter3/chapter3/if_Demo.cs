﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter3
{
    class if_Demo
    {
        static void Main()
        {
            Console.WriteLine("Please enter your annual income:");
            int anual_income = Convert.ToInt32(Console.ReadLine());

            if(anual_income >= 250000)
            {
                Console.WriteLine("You are liable to pay Income Tax");
            }else
            {
                Console.WriteLine("You are not liable to pay Income Tax");
            }

            Console.ReadLine();
        }
    }
}
