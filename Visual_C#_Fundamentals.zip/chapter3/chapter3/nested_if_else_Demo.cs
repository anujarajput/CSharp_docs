﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter3
{
    class nested_if_else_Demo
    {
        static void Main()
        {
            Console.WriteLine("Enter qualification(UG | PG):");
            string edu = Console.ReadLine();
            

            if(edu == "PG")
            {
                Console.WriteLine("Enter experience(in months):");
                int exp = Convert.ToInt32(Console.ReadLine());

                if (exp >= 12)
                {
                    Console.WriteLine("Elligible for this postion. Required Qualification and experience is matched.");
                }
                else
                {
                    Console.WriteLine("Not elligible for this postion. Required More than 12 months of experince.");
                }

            }
            else if(edu =="UG")
            {
                Console.WriteLine("Not elligible for this postion. Required Post graduation Qualification.");
            }
            else
            {
                Console.WriteLine("Invalid Choice...");
            }

            Console.ReadLine();
        }
    }
}
