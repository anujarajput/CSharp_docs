﻿using System;

namespace chapter3
{
    class switch_Demo
    {
        static void Main()
        {

            Console.WriteLine("Enter Item(Food| Services | Ornaments");
            string item = Console.ReadLine();

            switch (item)
            {
                case "Food":
                    Console.WriteLine("5%");
                    break;
                case "Services":
                    Console.WriteLine("8%");
                    break;
                case "Ornaments":
                    Console.WriteLine("12%");
                    break;
                default:
                    Console.WriteLine("Invalid Choice...");
                    break;

            }
            Console.ReadLine();
        }
    }
}
