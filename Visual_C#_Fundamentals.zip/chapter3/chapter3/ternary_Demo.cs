﻿using System;

namespace chapter3
{
    class ternary_Demo
    {
        static void Main()
        {
            Console.WriteLine("Please enter your annual income:");
            int anual_income = Convert.ToInt32(Console.ReadLine());

            string res = anual_income >= 250000 ? "You are liable to pay Income Tax" : "You are Not liable to pay Income Tax";

            Console.WriteLine(res);

            Console.ReadLine();
        }
    }
}
